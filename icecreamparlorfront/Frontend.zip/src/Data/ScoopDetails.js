export const data = [
    {
      id: '1',
      title: 'Vanilla Moon',
      price: 75.00,
      amountServed: '50gm/scoop',
    },

    {
      id: '2',
      title: 'Belgium Chocolate',
      price: 98.00,
      amountServed: '50gm/scoop',
    },
    {
      id: '3',
      title: 'Alphanso Mango',
      price: 105.50,
      amountServed: '50gm/scoop',
    },
    {
      id: '4',
      title: 'Strawberry Delight',
      price: 62.55,
      amountServed: '50gm/scoop',
    },
    {
      id: '5',
      title: 'Black Current',
      price: 99.15,
      amountServed: '50gm/scoop',
    },
    {
      id: '6',
      title: 'Butter Scotch',
      price: 120.05,
      amountServed: '50gm/scoop',
    },
    {
      id: '7',
      title: 'Red Velvet Oreo',
      price: 130.00,
      amountServed: '50gm/scoop',
    },
    {
      id: '8',
      title: 'Blue Heaven',
      price: 112.00,
      amountServed: '50gm/scoop',
    },
  ];

